package com.example.demo;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FormController {
	
	@Autowired
	CustomerRepo repo;
	@RequestMapping("/login")
	public String poorna() {
		return "landing";
	}
	@RequestMapping("/loginVerify")
	public String loginVerify(@RequestParam String cmail,@RequestParam String pwd)
	{
		List<Customer> ls = (List<Customer>) repo.findAll();
		Iterator<Customer> ils=ls.iterator();
		while(ils.hasNext())
		{
			String li=ils.next().toString();
			String[] lis=li.split(" ");
			String mail=lis[0];
			String password=lis[1];
			if(mail != null && password != null)
			{
				if(mail.compareTo(cmail) == 0 && password.compareTo(pwd) == 0)
				{
					return "welcome";
				}
			}
		}
		return "error";
	}
	@RequestMapping("/register")
	public String details() {
		return "Registrationform";
	}
	@RequestMapping("/details")
	public String details(Customer customer) {
		repo.save(customer);
		return "Registrationform";
	}
	
}
